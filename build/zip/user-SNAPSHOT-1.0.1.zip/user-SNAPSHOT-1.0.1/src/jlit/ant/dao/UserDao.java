/**
 * 
 */
package jlit.ant.dao;

import java.util.List;

import jlit.ant.idao.IUserDao;
import jlit.ant.vo.User;

/**
 * @author Gui
 *
 */
public class UserDao implements IUserDao {

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#add(jlit.ant.vo.User)
	 */
	@Override
	public void add(User user) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#deleteById(int)
	 */
	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#deleteByUsername(java.lang.String)
	 */
	@Override
	public void deleteByUsername(String username) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#update(jlit.ant.vo.User)
	 */
	@Override
	public void update(User user) {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#load(int)
	 */
	@Override
	public User load(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#login(java.lang.String, java.lang.String)
	 */
	@Override
	public User login(String username, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see jlit.ant.idao.IUserDao#list()
	 */
	@Override
	public List<User> list() {
		// TODO Auto-generated method stub
		return null;
	}

}
